package com.jpa.intermediate.repository.cart;

import com.jpa.intermediate.domain.CartDTO;
import com.jpa.intermediate.domain.QCartDTO;
import com.jpa.intermediate.entity.Cart;
import com.jpa.intermediate.entity.QCart;
import com.jpa.intermediate.entity.QMember;
import com.jpa.intermediate.entity.QProduct;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;

import java.util.List;

import static com.jpa.intermediate.entity.QCart.cart;
import static com.jpa.intermediate.entity.QMember.member;
import static com.jpa.intermediate.entity.QProduct.product;

@RequiredArgsConstructor
public class CartQueryDSLImpl implements CartQueryDSL {
    private final JPAQueryFactory query;

    @Override
    public List<CartDTO> findAll_QueryDSL() {
        return query.select(
                new QCartDTO(
                        cart.id,
                        cart.count,
                        cart.member.memberName,
                        cart.member.age,
                        cart.product.productName,
                        cart.product.productPrice,
                        cart.product.productStock
                        )
//        ).from(cart).join(member).on(cart.member.id.eq(member.id)).join(product).on(cart.product.id.eq(product.id)).fetchJoin().fetch();
        ).from(cart).join(cart.product, product).join(cart.member, member).fetch();
    }
}
