package com.jpa.intermediate.repository.product;

public interface ProductQueryDSL {
}
