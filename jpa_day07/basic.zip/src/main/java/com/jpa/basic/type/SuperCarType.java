package com.jpa.basic.type;

public enum SuperCarType {
    FERRARI, BENZ, BMW, LAMBORGHINI
}
