package com.jpa.expert.entity.car;

public enum CarBrand {
    LAMBORGHINI, FERRARI, PORSCHE, BMW, BENZ, AUDI, ASTON_MARTIN
}
