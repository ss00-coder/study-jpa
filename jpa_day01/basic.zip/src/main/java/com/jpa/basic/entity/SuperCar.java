package com.jpa.basic.entity;

import com.sun.istack.NotNull;
import lombok.Getter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter @ToString
@Table(name="TBL_SUPER_CAR")
public class SuperCar {
    @Id @GeneratedValue
    private Long id;
    @NotNull
    private String superCarBrand;
    private String superCarName;
    private String superCarColor;
    private Long superCarPrice;
    private LocalDateTime superCarReleaseDate;
}
