package com.jpa.basic.type;

public enum MemberType {
    MEMBER, ADMIN;
}
