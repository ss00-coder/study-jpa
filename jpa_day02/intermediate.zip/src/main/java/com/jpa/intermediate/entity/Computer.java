package com.jpa.intermediate.entity;

import com.sun.istack.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter @ToString
@Table(name = "TBL_COMPUTER")
public class Computer {
    @Id @GeneratedValue
    @EqualsAndHashCode.Include
    private Long id;
    @NotNull private int computerScreen;
    @NotNull private String computerBrand;
    @NotNull private String computerName;
    @NotNull private int computerPrice;
    @NotNull private LocalDateTime computerReleaseDate;

    @NotNull private int ram;
    @NotNull private int ssd;
    @NotNull private int gpu;
    @NotNull private int processor;
}





















