package com.jpa.intermediate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntermediateApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntermediateApplication.class, args);
    }

}
