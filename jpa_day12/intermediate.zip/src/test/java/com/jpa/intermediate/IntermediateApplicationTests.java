package com.jpa.intermediate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntermediateApplicationTests {

	@Test
	void contextLoads() {
	}

}
