package com.jpa.intermediate.repository.member;

public interface MemberQueryDSL {
}
