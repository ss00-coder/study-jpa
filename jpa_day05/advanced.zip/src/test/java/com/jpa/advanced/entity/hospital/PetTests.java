package com.jpa.advanced.entity.hospital;

import com.jpa.advanced.repository.hospital.OwnerDAO;
import com.jpa.advanced.repository.hospital.PetDAO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@SpringBootTest
@Slf4j
@Transactional
@Rollback(false)
public class PetTests {
    @Autowired
    private PetDAO petDAO;
    @Autowired
    private OwnerDAO ownerDAO;

    @Test
    public void saveTest(){
//        Owner owner = new Owner();
////        final Optional<Owner> foundOwner = ownerDAO.findById(12L);
//
//        Pet pet1 = new Pet();
//        Pet pet2 = new Pet();
//
//        owner.setOwnerName("홍길동");
//        owner.setOwnerPhone("01055556666");
////        ownerDAO.save(owner);
//
////        foundOwner.ifPresent(owner -> {
//            pet1.setPetDisease("피부병");
//            pet1.setPetGender(GenderType.FEMALE);
//            pet1.setPetName("뽀삐2");
//            pet1.setOwner(owner);
//            pet2.setPetDisease("감기");
//            pet2.setPetGender(GenderType.MALE);
//            pet2.setPetName("나비2");
//            pet2.setOwner(owner);
//
//            petDAO.save(pet1);
//            petDAO.save(pet2);
////        });
    }

    @Test
    public void findByIdTest(){

    }

    @Test
    public void findAllTest(){

    }

    @Test
    public void updateTest(){

    }

    @Test
    public void deleteTest(){
        final Optional<Owner> foundOwner = ownerDAO.findById(12L);
        foundOwner.ifPresent(ownerDAO::delete);
    }
}






















