package com.jpa.advanced.entity.hospital;

public enum GenderType {
    MALE, FEMALE
}
