package com.jpa.expert.repository.inquire;

import com.jpa.expert.entity.inquire.Answer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer, Long> {
}
