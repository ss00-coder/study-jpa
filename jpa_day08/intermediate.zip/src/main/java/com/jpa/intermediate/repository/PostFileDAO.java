package com.jpa.intermediate.repository;

public class PostFileDAO {
}
